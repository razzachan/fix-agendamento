
import os
from supabase import create_client, Client

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")

supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

def registrar_agendamento(data):
    return supabase.table("agendamentos_ai").insert({
        "nome": data.get("nome"),
        "endereco": data.get("endereco"),
        "equipamento": data.get("equipamento"),
        "problema": data.get("problema"),
        "urgente": data.get("urgente", False),
        "status": "pendente",
        "tecnico": data.get("tecnico")  # Pode ser None por padrão
    }).execute()
